Divergence Meter v1.0
===================================================================
Divergence Meter is an application based on Steins;Gate

Author: Daniel Luque

Notes
-------------------------------------------------------------------
 - Not remove w9xpopen.exe from app folder.

Llicense
-------------------------------------------------------------------
Divergence Meter licensed under terms of GPLv3
see license in: http://www.gnu.org/licenses/gpl-3.0.html

Source
-------------------------------------------------------------------
Github Repository: https://github.com/LuqueDaniel/Divergence-Meter.git
